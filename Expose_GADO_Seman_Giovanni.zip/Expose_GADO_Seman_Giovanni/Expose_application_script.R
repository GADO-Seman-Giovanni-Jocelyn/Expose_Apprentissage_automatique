                   #***************  Application  *******************#

        #**********Apprentissage automatique (réseaux de neurones)************ ###

#Importation des données
donnees = read.csv(file = "C:/Users/ASUS/Desktop/ISEP 2/Machine Learning/Inclusion financière/Train.csv",sep = ',')
View(donnees)

#Affichage des données
library(dplyr)
glimpse(donnees)

#Recherches des valeurs manquantes et suppression
donnees = as.data.frame(donnees)
donnees = na.omit(donnees)

#Suppression des variables sans intérêt
donnees$uniqueid = NULL

#Encodage des variables catégorielles
library(plyr)
donnees$country <- as.numeric(revalue(donnees$country, c("Kenya"=0, "Rwanda"=1, "Tanzania"=2, "Uganda"=3)))
donnees$bank_account <- as.numeric(revalue(donnees$bank_account, c("No"=0, "Yes"=1)))
donnees$cellphone_access <- as.numeric(revalue(donnees$cellphone_access, c("No"=0, "Yes"=1)))
donnees$gender_of_respondent <- as.numeric(revalue(donnees$gender_of_respondent, c("Female"=0, "Male"=1)))
donnees$location_type <- as.numeric(revalue(donnees$location_type, c("Rural"=0, "Urban"=1)))
donnees$relationship_with_head <- as.numeric(revalue(donnees$relationship_with_head, c("Child"=0, "Head of Household"=1, "Other non-relatives"=2, "Other relative"=3, "Parent"=4, "Spouse"=5)))
donnees$year <- as.character(donnees$year)
donnees$year <- as.numeric(revalue(donnees$year, c("2016"=0, "2017"=1, "2018"=2)))
donnees$marital_status <- as.numeric(revalue(donnees$marital_status, c("Divorced/Seperated"=0, "Dont know"=1, "Married/Living together"=2, "Single/Never Married"=3, "Widowed"=4)))
donnees$education_level <- as.numeric(revalue(donnees$education_level, c("No formal education"=0, "Other/Dont know/RTA"=1, "Primary education"=2, "Secondary education"=3, "Tertiary education"=4, "Vocational/Specialised training"=5)))
donnees$job_type <- as.numeric(revalue(donnees$job_type, c("Dont Know/Refuse to answer"=0, "Farming and Fishing"=1, "Formally employed Government"=2, "Formally employed Private"=3, "Government Dependent"=4, "Informally employed"=5, "No Income"=6, "Other Income"=7, "Remittance Dependent"=8, "Self employed"=9)))


set.seed(123)
# Calculer le nombre d'observations dans chaque classe de la variable "bank_account"
counts <- table(donnees$bank_account)

# Déterminer la taille d'échantillon désirée pour chaque classe
sample_size <- min(counts)

# Diviser les données en groupes basés sur la variable "bank_account"
grouped_data <- split(donnees, donnees$bank_account)

# Sous-échantillonner chaque groupe de manière équilibrée
balanced_data <- NULL

for (group in grouped_data) {
  # Vérifier si le groupe nécessite un équilibrage
  if (nrow(group) > sample_size) {
    # Sous-échantillonner les observations du groupe actuel
    sampled_rows <- sample(nrow(group), size = sample_size, replace = FALSE)

    # Ajouter les observations sous-échantillonnées au jeu de données équilibré
    balanced_data <- rbind(balanced_data, group[sampled_rows, ])
  } else {
    # Ajouter toutes les observations du groupe car il ne nécessite pas d'équilibrage
    balanced_data <- rbind(balanced_data, group)
  }
}

# Le jeu de données équilibré
balanced_data


#Séparation de notre de base de données en base de train et de test
library(caret)
#set.seed(123)
split_index <- createDataPartition(balanced_data$bank_account, p = 0.75, list = FALSE)
donnees_apprentissage <- balanced_data[split_index, ]
donnees_test <- balanced_data[-split_index, ]


#Implémentation du modèle de classification sans hyperparamètre
library(neuralnet)
model1 = neuralnet(bank_account~.,data=donnees_apprentissage,hidden=2,err.fct="ce",linear.output = FALSE)
plot(model1)
model1$weights
model1$result.matrix


#Affichage des probabilités d'appartenance
model1$net.result[[1]]
aff_model1 = ifelse(model1$net.result[[1]] > 0.5,1,0)
aff_model1


#Calcul de l'erreur d'apprentissage
erreur1 = mean(aff_model1 != donnees_apprentissage$bank_account)*100
erreur1


#Prédiction des valeus avec une nouvelle base de données
new.output= compute(model1,donnees_test)
new.output$net.result


#Effet de chacune des variables indépendantes sur la variable dépendante
par(mfrow=c(2,2))
gwplot(model1,selected.covariate = "country",min = 0 ,max = 3)
gwplot(model1,selected.covariate = "year",min = 0,max = 3)
gwplot(model1,selected.covariate = "location_type",min = 0,max = 3)
gwplot(model1,selected.covariate = "cellphone_access",min = 0,max = 3)
gwplot(model1,selected.covariate = "household_size",min = 0,max = 3)
gwplot(model1,selected.covariate = "age_of_respondent",min = 0,max = 3)
gwplot(model1,selected.covariate = "gender_of_respondent",min = 0,max = 3)
gwplot(model1,selected.covariate = "relationship_with_head",min = 0,max = 3)
gwplot(model1,selected.covariate = "marital_status",min = 0,max = 3)
gwplot(model1,selected.covariate = "education_level",min = 0,max =3 )
gwplot(model1,selected.covariate = "job_type",min = 0,max = 3)


#Nouvelle implémentation avec les variables "d'intérêt"
model11 = neuralnet(bank_account~cellphone_access+education_level,data=donnees_apprentissage,hidden=2,err.fct="ce",linear.output = FALSE)
plot(model11)
model11$weights
model11$result.matrix


#Affichage des probabilités d'appartenance
model11$net.result
aff_model11 = ifelse(unlist(model11$net.result) > 0.5,1,0)
aff_model11


#Calcul des erreurs
erreur11 = mean(aff_model11 != donnees_apprentissage$bank_account)*100
erreur11



























